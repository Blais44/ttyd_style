This mod partially is based on the announcer mod doctorpill has made. I only added these sounds based on the instructions he gave for his mods. The contents of this folder (specifically the .wav files) need to be moved to C:\Program Files(x86)\Steam\steamapps\common\ULTRAKILL\ULTRAKILL_Data\Audio for the mod to work.

For switching out ranks, you'll have to follow this little guide here: https://thunderstore.io/c/ultrakill/p/Waff1e/RankTitleSwapper/
You'll find the images you need in the Titles folder. Its enough if you copy the folder over the one that already exists for Waffles' Ultratweaker mod.

That should be it. Make sure to re-enable the RankTitleSwapper mod every time you boot up the game, it doesn't always boot up everything for some reason. If there are any issues for some reason, let me know.

Have fun! Enjoy˘˘
-Blais